(() => {
  const COOKIE_NAME = "flury_theme";
  const ACCENT_COOKIE_NAME = "flury_accent";
  const COOKIE_MAX_AGE = 60 * 60 * 24 * 365;
  const ACCENTS = {
    yellow: { primary: "#f9ab00", strong: "#ea8600" },
    purple: { primary: "#a142f4", strong: "#7b1fa2" },
    black: { primary: "#1f1f1f", strong: "#000000" },
    blue: { primary: "#1a73e8", strong: "#1558b0" },
    green: { primary: "#34a853", strong: "#1e8e3e" }
  };

  function readCookie(name) {
    const match = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : null;
  }

  function readStorage(name) {
    try {
      return window.localStorage.getItem(name);
    } catch (error) {
      return null;
    }
  }

  function writeStorage(name, value) {
    try {
      window.localStorage.setItem(name, value);
    } catch (error) {
    }
  }

  function writeCookie(name, value) {
    document.cookie = `${name}=${encodeURIComponent(value)}; path=/; max-age=${COOKIE_MAX_AGE}; samesite=lax`;
  }

  function readSetting(name) {
    return readStorage(name) || readCookie(name);
  }

  function writeSetting(name, value) {
    writeStorage(name, value);
    writeCookie(name, value);
  }

  function currentAccent() {
    const accent = document.documentElement.getAttribute("data-accent");
    return ACCENTS[accent] ? accent : "yellow";
  }

  function currentTheme() {
    return document.documentElement.getAttribute("data-theme") === "light" ? "light" : "dark";
  }

  function updateMeta(theme) {
    const themeColor = document.querySelector('meta[name="theme-color"]');
    if (themeColor) themeColor.setAttribute("content", theme === "light" ? "#f8fbff" : "#111827");

    const colorScheme = document.querySelector('meta[name="color-scheme"]');
    if (colorScheme) colorScheme.setAttribute("content", theme === "light" ? "light dark" : "dark light");
  }

  function syncAccent(accent) {
    document.querySelectorAll(".themeColorOption").forEach((button) => {
      button.setAttribute("aria-pressed", button.dataset.accent === accent ? "true" : "false");
    });
  }

  function applyAccent(accent, persist) {
    const next = ACCENTS[accent] ? accent : "yellow";
    const root = document.documentElement;
    const palette = ACCENTS[next];
    root.setAttribute("data-accent", next);
    root.style.setProperty("--theme-accent", palette.primary);
    root.style.setProperty("--theme-accent-strong", palette.strong);
    root.style.setProperty("--accent", palette.primary);
    root.style.setProperty("--accent2", palette.strong);
    syncAccent(next);
    if (persist) writeSetting(ACCENT_COOKIE_NAME, next);
  }

  function syncToggle(theme) {
    const toggle = document.getElementById("themeToggle");
    const icon = document.getElementById("themeToggleIcon");
    if (!toggle || !icon) return;

    const next = theme === "light" ? "dark" : "light";
    icon.innerHTML = theme === "light"
      ? '<circle cx="12" cy="12" r="4.5"></circle><path d="M12 2.75v2.1M12 19.15v2.1M21.25 12h-2.1M4.85 12h-2.1M18.54 5.46l-1.49 1.49M6.95 17.05l-1.49 1.49M18.54 18.54l-1.49-1.49M6.95 6.95 5.46 5.46"></path>'
      : '<path d="M14.8 3.35a8.9 8.9 0 1 0 5.85 15.57 7.45 7.45 0 1 1-5.85-15.57Z"></path>';
    toggle.setAttribute("aria-label", `Open theme settings. Next theme: ${next}`);
    toggle.setAttribute("title", `Open theme settings. Next theme: ${next}`);
    toggle.setAttribute("data-theme-state", theme);
  }

  function syncThemeButtons(theme) {
    document.querySelectorAll(".themeModeBtn").forEach((button) => {
      button.setAttribute("aria-pressed", button.dataset.themeOption === theme ? "true" : "false");
    });
  }

  function applyTheme(theme, persist) {
    const next = theme === "light" ? "light" : "dark";
    const root = document.documentElement;
    root.setAttribute("data-theme", next);
    root.style.colorScheme = next;
    updateMeta(next);
    syncToggle(next);
    syncThemeButtons(next);
    if (persist) writeSetting(COOKIE_NAME, next);
  }

  function createToggle() {
    const topbar = document.getElementById("topbar");
    if (!topbar || document.getElementById("themeToggle")) return;

    topbar.classList.add("hasThemePanel");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "themeToggle";
    button.id = "themeToggle";
    button.setAttribute("aria-expanded", "false");
    button.setAttribute("aria-controls", "themePanel");
    button.innerHTML = '<svg class="themeToggleIcon" id="themeToggleIcon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></svg>';
    button.addEventListener("click", () => {
      const isOpen = topbar.classList.toggle("theme-panel-open");
      button.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });

    const nav = topbar.querySelector("nav");
    if (nav && nav.parentNode === topbar) {
      topbar.insertBefore(button, nav);
    } else {
      topbar.appendChild(button);
    }

    const panel = document.createElement("div");
    panel.className = "themePanel";
    panel.id = "themePanel";
    panel.setAttribute("aria-label", "Theme settings");
    panel.innerHTML = `
      <div class="themePanelGroup">
        <div class="themePanelLabel">Theme</div>
        <div class="themeModeRow">
          <button type="button" class="themeModeBtn" data-theme-option="dark">Dark</button>
          <button type="button" class="themeModeBtn" data-theme-option="light">Light</button>
        </div>
      </div>
      <div class="themePanelGroup">
        <div class="themePanelLabel">Accent</div>
        <div class="themeColorsRow">
          <button type="button" class="btn themeColorOption" data-accent="yellow" aria-label="Yellow accent">
            <span class="themeColorIcon" aria-hidden="true">wb_sunny</span>
            <span class="themeColorLabel">Yellow</span>
          </button>
          <button type="button" class="btn themeColorOption" data-accent="purple" aria-label="Purple accent">
            <span class="themeColorIcon" aria-hidden="true">auto_awesome</span>
            <span class="themeColorLabel">Purple</span>
          </button>
          <button type="button" class="btn themeColorOption" data-accent="black" aria-label="Black accent">
            <span class="themeColorIcon" aria-hidden="true">dark_mode</span>
            <span class="themeColorLabel">Black</span>
          </button>
          <button type="button" class="btn themeColorOption" data-accent="blue" aria-label="Blue accent">
            <span class="themeColorIcon" aria-hidden="true">water_drop</span>
            <span class="themeColorLabel">Blue</span>
          </button>
          <button type="button" class="btn themeColorOption" data-accent="green" aria-label="Green accent">
            <span class="themeColorIcon" aria-hidden="true">eco</span>
            <span class="themeColorLabel">Green</span>
          </button>
        </div>
      </div>
    `;
    topbar.appendChild(panel);

    panel.querySelectorAll("[data-theme-option]").forEach((option) => {
      option.addEventListener("click", () => {
        applyTheme(option.dataset.themeOption, true);
      });
    });

    panel.querySelectorAll(".themeColorOption").forEach((option) => {
      option.addEventListener("click", () => {
        applyAccent(option.dataset.accent, true);
      });
    });

    document.addEventListener("click", (event) => {
      if (!topbar.contains(event.target)) {
        topbar.classList.remove("theme-panel-open");
        button.setAttribute("aria-expanded", "false");
      }
    });
  }

  function init() {
    createToggle();
    applyAccent(readSetting(ACCENT_COOKIE_NAME) || currentAccent(), false);
    applyTheme(readSetting(COOKIE_NAME) || currentTheme(), false);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
